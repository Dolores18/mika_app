export { unzlibSync } from 'fflate'

export { configure, ZipReader, BlobReader, TextWriter, BlobWriter } from '../node_modules/@zip.js/zip.js/lib/zip-no-worker-inflate.js'
